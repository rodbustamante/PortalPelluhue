<aside class="main-sidebar shop-sidebar">
	<?php dynamic_sidebar('shop'); ?>
</aside> <!-- /.main-sidebar -->