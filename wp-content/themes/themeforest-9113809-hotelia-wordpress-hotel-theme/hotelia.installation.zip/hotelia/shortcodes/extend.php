<?php

class WPBakeryShortCode_extend extends WPBakeryShortCode {
	
}